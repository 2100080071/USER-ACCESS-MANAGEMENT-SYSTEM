package com.example.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class ApprovalServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String requestId = request.getParameter("request_id");
        String action = request.getParameter("action");
        String newStatus = action.equals("Approve") ? "Approved" : "Rejected";

        try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/yourdb", "dbuser", "dbpassword");
             PreparedStatement stmt = conn.prepareStatement("UPDATE requests SET status = ? WHERE id = ?")) {
            stmt.setString(1, newStatus);
            stmt.setInt(2, Integer.parseInt(requestId));
            stmt.executeUpdate();
            response.sendRedirect("pendingRequests.jsp?success=true");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("pendingRequests.jsp?error=true");
        }
    }
}
