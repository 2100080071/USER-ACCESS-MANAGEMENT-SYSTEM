package com.example.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.example.servlets.AccessRequest;

public class PendingRequestsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String dbUrl = "jdbc:postgresql://localhost:5432/user_access_management_system";
        String dbUser = "postgres";
        String dbPassword = "Skam123$$";
        
        List<AccessRequest> pendingRequests = new ArrayList<>();
        
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
                PreparedStatement stmt = conn.prepareStatement(
                    "SELECT r.id, u.username, s.name AS software, r.access_type, r.reason " +
                    "FROM requests r " +
                    "JOIN users u ON r.user_id = u.id " +
                    "JOIN software s ON r.software_id = s.id " +
                    "WHERE r.status = 'Pending'"
                );
                ResultSet rs = stmt.executeQuery();
                
                while (rs.next()) {
                    AccessRequest requestObj = new AccessRequest(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("software"),
                        rs.getString("access_type"),
                        rs.getString("reason")
                    );
                    pendingRequests.add(requestObj);
                }
                
                // If no pending requests, add a placeholder AccessRequest with null values
                if (pendingRequests.isEmpty()) {
                    pendingRequests.add(new AccessRequest(0, null, null, null, null));
                }
                
                request.setAttribute("pendingRequests", pendingRequests);
                RequestDispatcher dispatcher = request.getRequestDispatcher("pendingRequests.jsp");
                dispatcher.forward(request, response);
                
            } catch (SQLException e) {
                e.printStackTrace();
                response.sendRedirect("error.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
