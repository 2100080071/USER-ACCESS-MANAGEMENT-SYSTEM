package com.example.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class SignUpServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = "Employee"; // Default role for new users

        String url = "jdbc:postgresql://localhost/user_access_management_system";
        String user = "postgres";
        String pass = "Skam123$$";
        
        try {
            // Load the PostgreSQL driver
            Class.forName("org.postgresql.Driver");

            // Establish a connection
            try (Connection conn = DriverManager.getConnection(url, user, pass)) {
                System.out.println("Database connection established successfully.");
                
                // Check if the username already exists
                String checkUserQuery = "SELECT COUNT(*) FROM users WHERE username = ?";
                try (PreparedStatement checkStmt = conn.prepareStatement(checkUserQuery)) {
                    checkStmt.setString(1, username);
                    ResultSet rs = checkStmt.executeQuery();
                    rs.next();
                    
                    int userCount = rs.getInt(1);
                    if (userCount > 0) {
                        // Username already exists, redirect to login page with error message
                        response.sendRedirect("login.jsp?error=Username already exists. Please log in.");
                    } else {
                        // Insert the new user
                        String insertUserQuery = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
                        try (PreparedStatement insertStmt = conn.prepareStatement(insertUserQuery)) {
                            insertStmt.setString(1, username);
                            insertStmt.setString(2, password); // Store hashed password in production
                            insertStmt.setString(3, role);
                            insertStmt.executeUpdate();
                            
                            // Set session attributes and redirect
                            HttpSession session = request.getSession();
                            session.setAttribute("username", username);
                            session.setAttribute("role", role);
                            response.sendRedirect("requestAccess.jsp?success=Successfully signed up and logged in.");
                        }
                    }
                }
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("signup.jsp?error=Database driver not found.");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("signup.jsp?error=An error occurred. Please try again.");
        }
    }
}
