package com.example.servlets;


public class AccessRequest {
    private int id;
    private String username;
    private String software;
    private String accessType;
    private String reason;
    
    // Constructor
    public AccessRequest(int id, String username, String software, String accessType, String reason) {
        this.id = id;
        this.username = username;
        this.software = software;
        this.accessType = accessType;
        this.reason = reason;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getSoftware() { return software; }
    public void setSoftware(String software) { this.software = software; }
    
    public String getAccessType() { return accessType; }
    public void setAccessType(String accessType) { this.accessType = accessType; }
    
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
}
