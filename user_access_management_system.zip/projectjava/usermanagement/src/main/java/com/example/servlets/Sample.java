package com.example.servlets;

import java.sql.*;
import java.sql.DriverManager;

public class Sample {
	private final String url="jdbc:postgresql://localhost/user_access_management_system";
	private final String user="postgres";
	private final String pass="Skam123$$";
	private void connect() {
		try(Connection conn=DriverManager.getConnection(url,user,pass);){
			if(conn!=null) {
				System.out.println("CONNECTED SQL");
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		Sample sq=new Sample();
		sq.connect();
	}
}
