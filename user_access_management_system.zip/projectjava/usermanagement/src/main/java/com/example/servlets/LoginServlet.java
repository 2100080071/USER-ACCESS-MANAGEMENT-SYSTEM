package com.example.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Hardcoded credentials (for testing purposes)
        String correctUsername = "Muveed";
        String correctPassword = "Skam123$$";

        // First check against hardcoded credentials (if applicable)
        if (username.equals(correctUsername) && password.equals(correctPassword)) {
            // Redirect to sample.html on successful login for hardcoded credentials
            response.sendRedirect("sample.html");
            return; // Exit method after redirect
        }

        // Database connection details (replace with actual values)
        String dbUrl = "jdbc:postgresql://localhost:5432/user_access_management_system";
        String dbUser = "postgres";
        String dbPassword = "Skam123$$";

        try {
            // Corrected line for loading the PostgreSQL driver
            Class.forName("org.postgresql.Driver");
            
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
                 PreparedStatement stmt = conn.prepareStatement("SELECT role FROM users WHERE username = ? AND password = ?")) {
                
                stmt.setString(1, username);
                stmt.setString(2, password); // Remember to hash passwords in production
                
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    // User found; retrieve role and create a session
                    String role = rs.getString("role");
                    
                    HttpSession session = request.getSession();
                    session.setAttribute("username", username);
                    session.setAttribute("role", role);

                    // Redirect user based on role
                    switch (role) {
                        case "Employee":
                            response.sendRedirect("requestAccess.jsp");
                            break;
                        case "Manager":
                            response.sendRedirect("pendingRequests.jsp");
                            break;
                        case "Admin":
                            response.sendRedirect("createSoftware.jsp");
                            break;
                        default:
                            response.sendRedirect("login.jsp?error=Role not recognized");
                            break;
                    }
                } else {
                	response.sendRedirect("requestAccess.jsp");
                    // Exit method after redirect
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace(); // Log the error for debugging
            response.sendRedirect("login.jsp?error=Database error, please try again");
        }
    }
}
