package com.example.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class RequestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String softwareId = request.getParameter("software_id");
        String accessType = request.getParameter("access_type");
        String reason = request.getParameter("reason");
        
        String dbUrl = "jdbc:postgresql://localhost:5432/user_access_management_system";
        String dbUser = "postgres";
        String dbPassword = "Skam123$$";

        try {
            // Load the PostgreSQL driver
            Class.forName("org.postgresql.Driver");

            // Establish the database connection
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);) {
                PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO requests (user_id, software_id, access_type, reason, status) " +
                    "VALUES ((SELECT id FROM users WHERE username=?), ?, ?, ?, 'Pending')"
                );
                stmt.setString(1, "Mani");
                stmt.setInt(2, Integer.parseInt(softwareId));
                stmt.setString(3, accessType);
                stmt.setString(4, reason);
                stmt.executeUpdate();
                response.sendRedirect("requestAccess.jsp?success=true");
            } catch (SQLException e) {
                e.printStackTrace();
                response.sendRedirect("requestAccess.jsp?error=true");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("requestAccess.jsp?error=true");
        }
    }
}
